
package com.example.carfaxassignment.beans;

import java.io.Serializable;

public class PriceRange implements Serializable {

    private Integer min;

    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

}
